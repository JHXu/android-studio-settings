<template>
  <div class="#[[$END$]]#">
  </div>
</template>

<script>
export default {
  name: "${COMPONENT_NAME}",
  data() {
    return {}
  },
  methods: {}
}
</script>

<style lang="scss" scoped>

</style>